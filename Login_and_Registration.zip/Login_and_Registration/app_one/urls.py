from django.urls import path
from .import views


urlpatterns = [
    path('', views.main),
    path('create', views.create),
    path('success', views.success),
    path('login', views.login)
    # path('wipeDB', views.wipeDB)
]